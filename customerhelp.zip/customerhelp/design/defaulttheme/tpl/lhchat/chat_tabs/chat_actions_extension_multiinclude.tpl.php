<?php 
/**
 * Please override this template, there can go custom chat actions
 * */?>