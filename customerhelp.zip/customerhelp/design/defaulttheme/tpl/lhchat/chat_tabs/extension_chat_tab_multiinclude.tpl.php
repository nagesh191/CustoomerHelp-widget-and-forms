<?php 
/**
 * Override me and have any tab you want there, $chat variable will contain chat itself
 * 
 * <li role="presentation" class="active"><a href="#main-extension-chat-<?php echo $chat->id?>" aria-controls="main-extension-chat-<?php echo $chat->id?>" role="tab" data-toggle="tab" title="<?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/adminchat','Extension tab title')?>"><i class="material-icons">face</i></a></li>
 * */?>