<?php foreach ($items as $chat) : ?>
<?php include(erLhcoreClassDesign::designtpl('lhchat/printchat.tpl.php')); ?>
<hr>
<?php endforeach;?>