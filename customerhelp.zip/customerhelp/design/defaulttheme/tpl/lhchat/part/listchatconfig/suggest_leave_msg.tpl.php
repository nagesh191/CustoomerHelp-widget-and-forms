<?php $attribute = 'suggest_leave_msg';$boolValue = true;?>
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>