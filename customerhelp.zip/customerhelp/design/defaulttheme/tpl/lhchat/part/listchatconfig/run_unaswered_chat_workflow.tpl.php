<?php $attribute = 'run_unaswered_chat_workflow'?>
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>