<img alt=":)" src="<?php echo erLhcoreClassDesign::design('images/smileys/emoticon_smile.png')?>" />||
<img alt=":D:" src="<?php echo erLhcoreClassDesign::design('images/smileys/emoticon_happy.png')?>" />||
<img alt=":(" src="<?php echo erLhcoreClassDesign::design('images/smileys/emoticon_unhappy.png')?>" />||
<img alt=":o:" src="<?php echo erLhcoreClassDesign::design('images/smileys/emoticon_surprised.png')?>" />||
<img alt=":p:" src="<?php echo erLhcoreClassDesign::design('images/smileys/emoticon_tongue.png')?>" />||
<img alt=";)" src="<?php echo erLhcoreClassDesign::design('images/smileys/emoticon_wink.png')?>" />
